// Save fields logic
