// SmartFill Content Script - Field Detection Engine
// Runs isolated in the webpage
const ALIASES = {
    full_name: ['full name', 'applicant name', 'your name', 'candidate name', 'name'],
    first_name: ['first name', 'given name', 'fname'],
    last_name: ['last name', 'family name', 'surname', 'lname'],
    email: ['email address', 'email', 'work email', 'personal email', 'e-mail'],
    phone: ['phone', 'mobile number', 'contact number', 'cell phone', 'phone number', 'tel', 'telephone'],
    address: ['address', 'street address', 'address line 1', 'home address', 'residential address'],
    city: ['city', 'town', 'municipality'],
    state: ['state', 'province', 'region', 'county'],
    country: ['country', 'nation'],
    postal_code: ['postal code', 'zip code', 'zip', 'post code', 'postcode'],
    linkedin: ['linkedin profile', 'linkedin url', 'linkedin'],
    github: ['github profile', 'github url', 'github'],
    portfolio: ['portfolio', 'personal website', 'website', 'blog url'],
    university: ['university', 'college', 'school', 'institution'],
    degree: ['degree', 'qualification', 'major', 'program of study'],
    graduation_year: ['graduation year', 'grad year', 'class of', 'year of graduation'],
    skills: ['skills', 'core competencies', 'technical skills', 'technologies'],
    resume: ['resume', 'cv', 'resume link', 'cv link', 'resume drive link', 'upload the resume', 'curriculum vitae'],
    cgpa: ['cgpa', 'gpa', 'grades', 'grade point average', 'gpa score'],
};
const FORBIDDEN = [
    'password', 'passwd', 'pwd', 'otp', 'one time', 'cvv', 'cvc', 'security code',
    'card number', 'credit card', 'ssn', 'social security', 'pin', 'verification code',
];
// Whole-word match so 'pin' doesn't block "Shipping Address" and 'otp' doesn't
// block "Footprint". Runs against the normalized hint blob (lowercase, single spaces).
const FORBIDDEN_RE = new RegExp(`\\b(?:${FORBIDDEN.map((k) => k.replace(/\s+/g, '\\s+')).join('|')})\\b`);
// Unambiguous keywords still match inside compact names/ids like "newpassword".
const FORBIDDEN_SUBSTRINGS = ['password', 'passwd'];
function normalize(s) {
    if (!s)
        return '';
    return s.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
}
const COMMON_PLACEHOLDERS = new Set([
    'your answer',
    'short answer',
    'paragraph answer',
    'select an option',
    'choose',
    'choose an option',
    'answer',
    'optional',
]);
function isCommonPlaceholder(text) {
    return COMMON_PLACEHOLDERS.has(normalize(text));
}
function addTextHint(target, text) {
    if (!text)
        return;
    if (isCommonPlaceholder(text))
        return;
    const candidate = text.trim();
    if (!candidate)
        return;
    const existing = target.label.split('\n').map(normalize);
    if (!existing.includes(normalize(candidate))) {
        target.label += (target.label ? '\n' : '') + candidate;
    }
}
function elementText(node) {
    return (node.innerText || node.textContent || '').trim();
}
function isForbidden(el, hints) {
    if (el.type === 'password')
        return true;
    // Split camelCase ("otpCode", "cardNumber") so whole-word matching sees the parts.
    const raw = [hints.label, hints.ariaLabel, hints.placeholder, hints.name, hints.id].join(' ');
    const blob = normalize(raw.replace(/([a-z0-9])([A-Z])/g, '$1 $2'));
    return FORBIDDEN_RE.test(blob) || FORBIDDEN_SUBSTRINGS.some((k) => blob.includes(k));
}
function fieldHints(el) {
    const hints = { label: '', placeholder: '', name: '', id: '', ariaLabel: '' };
    if (el.name)
        hints.name = el.name;
    if (el.id)
        hints.id = el.id;
    if (el.placeholder)
        hints.placeholder = el.placeholder;
    if (el.getAttribute && el.getAttribute('aria-label'))
        hints.ariaLabel = el.getAttribute('aria-label');
    try {
        if (el.id) {
            const lbl = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
            if (lbl)
                addTextHint(hints, elementText(lbl));
        }
        const parentLabel = el.closest && el.closest('label');
        if (parentLabel)
            addTextHint(hints, elementText(parentLabel));
        const labelledBy = el.getAttribute && el.getAttribute('aria-labelledby');
        if (labelledBy) {
            for (const id of labelledBy.split(/\s+/)) {
                const node = document.getElementById(id);
                if (node)
                    addTextHint(hints, elementText(node));
            }
        }
        const describedBy = el.getAttribute && el.getAttribute('aria-describedby');
        if (describedBy) {
            for (const id of describedBy.split(/\s+/)) {
                const node = document.getElementById(id);
                if (node)
                    addTextHint(hints, elementText(node));
            }
        }
        let container = el;
        for (let depth = 0; depth < 5 && container; depth += 1) {
            if (container !== el) {
                if (container.getAttribute('aria-labelledby')) {
                    for (const id of container.getAttribute('aria-labelledby').split(/\s+/)) {
                        const node = document.getElementById(id);
                        if (node)
                            addTextHint(hints, elementText(node));
                    }
                }
                if (container.getAttribute('aria-label')) {
                    addTextHint(hints, container.getAttribute('aria-label'));
                }
            }
            const heading = container.querySelector('[role="heading"], h1, h2, h3, h4, h5, h6, legend, .question-title, .freebirdFormviewerComponentsQuestionBaseTitle, .freebirdFormviewerComponentsQuestionBaseText, .M7eMe');
            if (heading)
                addTextHint(hints, elementText(heading));
            const childTexts = Array.from(container.querySelectorAll('label, legend, [role="heading"], [aria-level], .question-title, .freebirdFormviewerComponentsQuestionBaseTitle, .freebirdFormviewerComponentsQuestionBaseText, .M7eMe'));
            for (const node of childTexts) {
                addTextHint(hints, elementText(node));
            }
            // The nearest labelled container owns this field. Going higher can mix in
            // labels from sibling questions, which is common in Google Forms.
            if (heading || childTexts.length > 0)
                break;
            container = container.parentElement;
        }
    }
    catch {
        // Best-effort label extraction; inaccessible selectors should not block matching.
    }
    return hints;
}
// Aliases too generic to stand on their own. A bare "name" qualified by a
// preceding word ("College Name", "Company Name", "Father's Name") describes
// something else, so it only scores as a weak hint below the 0.75 autofill
// threshold. Keep this logic in sync with src/services/autofill/fieldMatcher.ts.
const GENERIC_ALIASES = new Set(['name']);
const GENERIC_QUALIFIED_CONFIDENCE = 0.6;
function escapeRegex(s) {
    return s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');
}
function wordMatchConfidence(token, normalizedAlias) {
    const escapedAlias = escapeRegex(normalizedAlias);
    if (!new RegExp(`\\b${escapedAlias}\\b`, 'i').test(token))
        return 0;
    if (GENERIC_ALIASES.has(normalizedAlias) && new RegExp(`\\S\\s+${escapedAlias}\\b`, 'i').test(token)) {
        return GENERIC_QUALIFIED_CONFIDENCE;
    }
    return 0.85;
}
function evaluateRules(inputTokens) {
    let bestMatch = { canonicalField: null, confidence: 0 };
    let bestAliasLength = 0;
    // Higher confidence wins; on a tie the longer (more specific) alias wins.
    const consider = (canonicalField, alias, confidence) => {
        const aliasLength = normalize(alias).length;
        if (confidence > bestMatch.confidence || (confidence === bestMatch.confidence && aliasLength > bestAliasLength)) {
            bestMatch = { canonicalField, confidence };
            bestAliasLength = aliasLength;
        }
    };
    for (const [canonicalField, aliases] of Object.entries(ALIASES)) {
        for (const alias of aliases) {
            const normalizedAlias = normalize(alias);
            for (const token of inputTokens) {
                if (!token)
                    continue;
                // 1. Exact match
                if (token === normalizedAlias) {
                    return { canonicalField, confidence: 0.95 };
                }
                // 2. Whole word match (e.g. "college" in "college name")
                const wordConfidence = wordMatchConfidence(token, normalizedAlias);
                if (wordConfidence > 0)
                    consider(canonicalField, alias, wordConfidence);
                // 3. Substring match fallback, only for reasonably long strings
                if (normalizedAlias.length > 3 && token.length > 3) {
                    if (token.includes(normalizedAlias) || normalizedAlias.includes(token)) {
                        const ratio = Math.min(token.length, normalizedAlias.length) / Math.max(token.length, normalizedAlias.length);
                        let confidence = 0.5 + (ratio * 0.3); // Base 0.5, max 0.8
                        if (GENERIC_ALIASES.has(normalizedAlias))
                            confidence = Math.min(confidence, GENERIC_QUALIFIED_CONFIDENCE);
                        consider(canonicalField, alias, confidence);
                    }
                }
            }
        }
    }
    return bestMatch;
}
function classify(el) {
    const hints = fieldHints(el);
    if (isForbidden(el, hints)) {
        return { canonicalField: null, confidence: 0 };
    }
    const normalizedSources = {
        labels: hints.label.split('\n').map(normalize).filter(Boolean),
        ariaLabel: normalize(hints.ariaLabel),
        placeholder: normalize(hints.placeholder),
        name: normalize(hints.name),
        id: normalize(hints.id),
    };
    let result = evaluateRules([...normalizedSources.labels, normalizedSources.ariaLabel]);
    if (result.confidence >= 0.5)
        return result;
    result = evaluateRules([normalizedSources.placeholder]);
    if (result.confidence >= 0.5)
        return result;
    result = evaluateRules([normalizedSources.name, normalizedSources.id]);
    if (result.confidence >= 0.5)
        return result;
    return { canonicalField: null, confidence: 0 };
}
window.__SMARTFILL__ = { classify, isForbidden, fieldHints, ALIASES };
//# sourceMappingURL=detectFields.js.map